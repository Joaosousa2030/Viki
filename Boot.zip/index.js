const { Client, GatewayIntentBits, EmbedBuilder, PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

// Mapa para armazenar os usuários AFK e o tempo que estão AFK
const afkMap = new Map();

// Coloque seu ID de usuário aqui
const ADMIN_ID = '1223343381531328575'; // Substitua pelo seu ID de usuário

// Quando o bot estiver online
client.once('ready', () => {
    console.log('Bot está online!');
});

// Respostas aos comandos
client.on('messageCreate', async message => {
    if (message.author.bot) return;

    // Responder quando o bot for mencionado
    if (message.mentions.has(client.user)) {
        message.channel.send(`Olá <@${message.author.id}>! Eu sou o seu bot. Para consultar os comandos disponíveis, digite \`vhelp\`.`);
    }

    const content = message.content.toLowerCase();

    // Comando vping
    if (content === 'vping') {
        const latency = Math.round(client.ws.ping);
        message.channel.send(`Pong! \`${latency}ms\``);
    }

    // Comando vafk
    if (content.startsWith('vafk')) {
        const role = message.guild.roles.cache.find(r => r.name === 'AFK');
        if (!role) {
            return message.channel.send('O cargo AFK não existe no servidor.');
        }

        await message.member.roles.add(role);
        const afkTime = Date.now(); // Captura o tempo em que o usuário se tornou AFK
        afkMap.set(message.author.id, afkTime); // Armazena o tempo AFK

        message.channel.send(`<@${message.author.id}> está agora AFK.`);

        // Listener para remover o cargo AFK após o membro enviar uma mensagem
        const filter = m => m.author.id === message.author.id;
        const collector = message.channel.createMessageCollector({ filter, time: 86400000 }); // 24 horas para evitar infinito

        collector.on('collect', async () => {
            await message.member.roles.remove(role);
            afkMap.delete(message.author.id); // Remove o tempo AFK
            message.channel.send(`<@${message.author.id}>, você não está mais AFK.`);
            collector.stop(); // Para de escutar mensagens após a primeira mensagem enviada
        });
    }

    // Verifica se o membro mencionado está AFK
    const mentionedMember = message.mentions.members.first();
    if (mentionedMember && afkMap.has(mentionedMember.id)) {
        const afkDuration = Math.floor((Date.now() - afkMap.get(mentionedMember.id)) / 1000); // Tempo AFK em segundos
        message.channel.send(`<@${mentionedMember.id}> está AFK há ${afkDuration} segundos.`);
    }

    // Comando vhelp (em formato de embed com cor vermelha)
    if (content === 'vhelp') {
        const helpEmbed = new EmbedBuilder()
            .setColor('#a70e0e') // Cor vermelha
            .setTitle('Comandos Disponíveis')
            .setDescription('Aqui estão os comandos disponíveis:')
            .addFields(
                { name: 'vping', value: 'Mostra a latência do bot.' },
                { name: 'vhelp', value: 'Mostra todos os comandos disponíveis.' },
                { name: 'vafk', value: 'Define seu status como AFK.' },
                { name: 'vconvite', value: 'Gera um link de convite para o servidor.' },
                { name: 'vavatar @user', value: 'Mostra o avatar do usuário mencionado.' }
            )
            .setThumbnail(client.user.displayAvatarURL());

        message.channel.send({ embeds: [helpEmbed] });
    }

    // Comando vhelp adm (somente para o admin)
    if (content === 'vhelp adm') {
        if (message.author.id !== ADMIN_ID) {
            return message.reply('Você não tem permissão para usar esse comando.');
        }

        const adminHelpEmbed = new EmbedBuilder()
            .setColor('#a70e0e') // Cor vermelha
            .setTitle('Comandos Administrativos')
            .setDescription('Aqui estão os comandos administrativos disponíveis:')
            .addFields(
                { name: 'vmute @user [tempo]', value: 'Muta o usuário mencionado pelo tempo especificado.' },
                { name: 'vunmute @user', value: 'Desmuta o usuário mencionado.' },
                { name: 'vban @user [motivo]', value: 'Bane o usuário mencionado com um motivo.' },
                { name: 'vexpulsar @user [motivo]', value: 'Expulsa o usuário mencionado com um motivo.' },
                { name: 'vclear [número]', value: 'Apaga uma quantidade específica de mensagens.' }
            )
            .setThumbnail(client.user.displayAvatarURL());

        message.channel.send({ embeds: [adminHelpEmbed] });
    }

    // Comando vconvite
    if (content === 'vconvite') {
        const inviteEmbed = new EmbedBuilder()
            .setColor('#a70e0e') // Cor vermelha
            .setTitle('Convites')
            .setDescription('Escolha uma opção:')
            .setThumbnail(client.user.displayAvatarURL());

        // Botões para adicionar o bot e para o servidor oficial
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setLabel('Me Adicione')
                    .setURL('https://discord.com/oauth2/authorize?client_id=1256323181049024532&scope=bot&permissions=8')
                    .setStyle(ButtonStyle.Link),
                new ButtonBuilder()
                    .setLabel('Servidor Oficial')
                    .setURL('https://discord.gg/SDyuCPEbnh')
                    .setStyle(ButtonStyle.Link)
            );

        message.channel.send({ embeds: [inviteEmbed], components: [row] });
    }

    // Comando vclear
    if (content.startsWith('vclear')) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return message.reply('Você não tem permissão para usar esse comando.');
        }

        const args = content.split(' ').slice(1);
        const amount = parseInt(args[0]);

        if (!amount || amount < 1 || amount > 100) {
            return message.reply('Por favor, forneça um número entre 1 e 100.');
        }

        // Apagar as mensagens, excluindo a própria mensagem de comando
        const fetchedMessages = await message.channel.messages.fetch({ limit: amount + 1 }); // Pega as mensagens, incluindo a do comando
        const messagesToDelete = fetchedMessages.filter(msg => msg.id !== message.id); // Filtra a mensagem do comando

        await message.channel.bulkDelete(messagesToDelete, true).catch(error => {
            console.error(error);
            message.channel.send('Ocorreu um erro ao tentar apagar as mensagens.');
        });

        // Mensagem de confirmação
        const deleteMessage = await message.channel.send(`\`${amount}\` mensagens foram apagadas.`);

        // Apagar a mensagem de comando após 0 segundos (instantaneamente)
        await message.delete().catch(err => console.error(err));

        // Apagar a mensagem de confirmação após 2 segundos
        setTimeout(() => {
            deleteMessage.delete().catch(err => console.error(err));
        }, 2000);
    }

    // Comando vmute
    if (content.startsWith('vmute')) {
        if (!message.member.permissions.has('MANAGE_ROLES')) {
            return message.reply('Você não tem permissão para usar esse comando.');
        }

        const userToMute = message.mentions.members.first();
        const durationString = content.split(' ').slice(2).join(' '); // Pega a duração
        const duration = parseDuration(durationString); // Converte a duração para milissegundos

        if (userToMute) {
            let role = message.guild.roles.cache.find(r => r.name === 'Muted');
            if (!role) {
                // Cria o cargo "Muted" se não existir
                role = await message.guild.roles.create({
                    name: 'Muted',
                    permissions: []
                });

                // Atualiza permissões nos canais
                message.guild.channels.cache.forEach(async (channel) => {
                    await channel.permissionOverwrites.create(role, { 
                        SEND_MESSAGES: false, 
                        ADD_REACTIONS: false, 
                        SPEAK: false,
                        CONNECT: false
                    });
                });

                message.channel.send('Cargo "Muted" criado.');
            }

            // Adiciona o cargo de "Muted" ao usuário
            await userToMute.roles.add(role);

            // Primeira mensagem sem mencionar o usuário
            message.channel.send(`${userToMute.user.username} foi mutado.`);

            // Segunda mensagem mencionando o usuário e indicando o tempo de mute
            message.channel.send(`<@${userToMute.id}> você foi mutado por ${durationString}.`);

            // Remove o mute após o tempo especificado
            if (duration) {
                setTimeout(async () => {
                    await userToMute.roles.remove(role);
                    message.channel.send(`${userToMute.user.username} foi desmutado após ${durationString}.`);
                }, duration);
            }
        } else {
            message.channel.send('Você deve mencionar um usuário para mutar.');
        }
    }

    // Comando vunmute
    if (content.startsWith('vunmute')) {
        if (!message.member.permissions.has('MANAGE_ROLES')) {
            return message.reply('Você não tem permissão para usar esse comando.');
        }

        const userToUnmute = message.mentions.members.first();
        if (userToUnmute) {
            const role = message.guild.roles.cache.find(r => r.name === 'Muted');
            if (role) {
                await userToUnmute.roles.remove(role);
                message.channel.send(`${userToUnmute.user.username} foi desmutado.`);
            } else {
                message.channel.send('O cargo "Muted" não existe.');
            }
        } else {
            message.channel.send('Você deve mencionar um usuário para desmutar.');
        }
    }

    // Comando vban
    if (content.startsWith('vban')) {
        if (!message.member.permissions.has('BAN_MEMBERS')) {
            return message.reply('Você não tem permissão para usar esse comando.');
        }

        const userToBan = message.mentions.members.first();
        const reason = content.split(' ').slice(2).join(' ') || 'Sem motivo especificado.';

        if (userToBan) {
            await userToBan.ban({ reason });
            message.channel.send(`${userToBan.user.username} foi banido. Motivo: ${reason}`);
        } else {
            message.channel.send('Você deve mencionar um usuário para banir.');
        }
    }

    // Comando vexpulsar
    if (content.startsWith('vexpulsar')) {
        if (!message.member.permissions.has('KICK_MEMBERS')) {
            return message.reply('Você não tem permissão para usar esse comando.');
        }

        const userToKick = message.mentions.members.first();
        const reason = content.split(' ').slice(2).join(' ') || 'Sem motivo especificado.';

        if (userToKick) {
            await userToKick.kick(reason);
            message.channel.send(`${userToKick.user.username} foi expulso. Motivo: ${reason}`);
        } else {
            message.channel.send('Você deve mencionar um usuário para expulsar.');
        }
    }

    // Comando vavatar
    if (content.startsWith('vavatar')) {
        const userToShow = message.mentions.users.first() || message.author;
        const avatarEmbed = new EmbedBuilder()
            .setColor('#a70e0e') // Cor vermelha
            .setTitle(`${userToShow.username}'s Avatar`)
            .setImage(userToShow.displayAvatarURL({ dynamic: true, size: 1024 }));

        message.channel.send({ embeds: [avatarEmbed] });
    }

    // Função para converter a duração para milissegundos
    function parseDuration(durationString) {
        const regex = /(\d+)\s*(min|minuto|s|segundo)/gi; // Regex para encontrar a duração
        let totalMilliseconds = 0;

        const matches = durationString.match(regex);
        if (matches) {
            matches.forEach(match => {
                const [_, value, unit] = match.match(/(\d+)\s*(min|minuto|s|segundo)/i);
                const timeValue = parseInt(value);
                if (unit.toLowerCase().startsWith('min')) {
                    totalMilliseconds += timeValue * 60 * 1000; // Converte minutos para milissegundos
                } else if (unit.toLowerCase().startsWith('s')) {
                    totalMilliseconds += timeValue * 1000; // Converte segundos para milissegundos
                }
            });
        }

        return totalMilliseconds > 0 ? totalMilliseconds : null; // Retorna null se não houver duração válida
    }
});

// Logando o bot
client.login('MTI1NjMyMzE4MTA0OTAyNDUzMg.GtwrfE.c_IjDa2R5Dj6o1iyzUWG3wUI5yKPj16iENspdo'); // Substitua pelo seu token
